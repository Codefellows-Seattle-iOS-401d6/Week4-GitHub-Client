//
//  OAuthViewController.swift
//  GoGoGithub
//
//  Created by Michael Babiy on 10/22/15.
//  Copyright © 2015 Michael Babiy. All rights reserved.
//

import UIKit

class OAuthViewController: UIViewController, Setup
{
    @IBOutlet weak var loginButton: UIButton!

    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.setup()
        self.setupAppearance()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    func setup()
    {
        //
    }
    
    func setupAppearance()
    {
        self.loginButton.layer.cornerRadius = 3.0
    }
    
    @IBAction func loginButtonSelected(sender: UIButton)
    {
        MBGithubOAuth.shared.oauthRequestWith("email,user,repo")
    }
}
