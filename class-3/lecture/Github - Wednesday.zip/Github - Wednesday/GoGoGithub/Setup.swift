//
//  Setup.swift
//  GoGoGithub
//
//  Created by Michael Babiy on 6/27/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import Foundation

protocol Setup
{
    static var id: String { get }
    func setup()
    func setupAppearance()
}

extension Setup
{
    static var id: String {
        return String(self)
    }
}