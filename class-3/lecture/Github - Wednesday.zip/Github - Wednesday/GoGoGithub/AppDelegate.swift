//
//  AppDelegate.swift
//  GoGoGithub
//
//  Created by Michael Babiy on 10/21/15.
//  Copyright © 2015 Michael Babiy. All rights reserved.
//

import UIKit

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate
{
    var window: UIWindow?
    var oauthViewController: OAuthViewController?
    var homeViewController: HomeViewController?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool
    {
        self.checkOAuthStatus()
        return true
    }
    
    func application(application: UIApplication, openURL url: NSURL, sourceApplication: String?, annotation: AnyObject) -> Bool
    {
        MBGithubOAuth.shared.tokenRequestWithCallback(url, options: SaveOptions.UserDefaults) { (success) -> () in
            if success {
                if let oauthViewController = self.oauthViewController {
                    UIView.animateWithDuration(0.4, delay: 1.6, options: .CurveEaseInOut, animations: {
                        
                        self.homeViewController?.navigationController?.navigationBarHidden = false
                        oauthViewController.view.alpha = 0.0
                        
                        }, completion: { (finished) in
                            oauthViewController.view.removeFromSuperview()
                            oauthViewController.removeFromParentViewController()
                            
                            // GET all repositories. 
                            
                            self.homeViewController?.update()
                    })
                }
            }
        }
        
        return true
    }
    
    // MARK: Setup
    
    func checkOAuthStatus() {
        
        do {
            
            let token = try MBGithubOAuth.shared.accessToken()
            print(token)
            
        } catch _ { self.presentOAuthViewController() }
        
    }
    
    func presentOAuthViewController()
    {
        guard let navigationController = self.window?.rootViewController as? UINavigationController else { fatalError("Check your root view controller.") }
        navigationController.navigationBarHidden = true
        
        guard let homeViewController = navigationController.viewControllers.first as? HomeViewController else { fatalError("Home VC?") }
        guard let storyboard = homeViewController.storyboard else { fatalError("Check for storyboard.") }
        guard let oauthViewController = storyboard.instantiateViewControllerWithIdentifier(OAuthViewController.id) as? OAuthViewController else { fatalError("Error...") }
        
        homeViewController.addChildViewController(oauthViewController)
        homeViewController.view.addSubview(oauthViewController.view)
        oauthViewController.didMoveToParentViewController(homeViewController)
        
        self.homeViewController = homeViewController
        self.oauthViewController = oauthViewController
    }

}

