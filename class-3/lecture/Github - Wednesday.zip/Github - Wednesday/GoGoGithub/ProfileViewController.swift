//
//  ProfileViewController.swift
//  GoGoGithub
//
//  Created by Michael Babiy on 6/28/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import UIKit

protocol ProfileViewControllerDelegate: class
{
    func profileViewControllerDidFinish()
}

class ProfileViewController: UIViewController
{
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var closeButton: UIButton!
    
    weak var delegate: ProfileViewControllerDelegate?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.setup()
        self.setupAppearance()
    }
    
    override func viewWillAppear(animated: Bool)
    {
        super.viewWillAppear(animated)
        self.update()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    func update()
    {
        API.shared.GETUser { (user) in
            if let user = user {
                self.nameLabel.text = user.name
                self.locationLabel.text = user.location
            }
        }
    }
    
    @IBAction func closeButtonSelected(sender: UIButton)
    {
        self.delegate?.profileViewControllerDidFinish()
    }
}

extension ProfileViewController: Setup
{
    func setup()
    {
        //
    }
    
    func setupAppearance()
    {
        self.closeButton.layer.cornerRadius = 3.0
    }
}