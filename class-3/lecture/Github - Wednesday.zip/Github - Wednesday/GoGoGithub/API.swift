//
//  API.swift
//  GoGoGithub
//
//  Created by Michael Babiy on 6/27/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import Foundation

class API
{
    static let shared = API()
    
    private let session: NSURLSession
    private let template: NSURLComponents
    
    private init()
    {
        self.session = NSURLSession(configuration: .defaultSessionConfiguration())
        self.template = NSURLComponents()
        self.configure()
    }
    
    private func configure()
    {
        self.template.scheme = "https"
        self.template.host = "api.github.com"
        
        do {
            if let token = try MBGithubOAuth.shared.accessToken() {
                template.queryItems = [NSURLQueryItem(name: "access_token", value: token)]
            }
        }
            
        catch {}
    }
    
    func GETRepositories(completion: (repositories: [Repository]?) -> ())
    {
        self.template.path = "/user/repos"
        self.session.dataTaskWithURL(self.template.URL!) { (data, response, error) in
            
            if let _ = error { self.returnOnMain(nil, completion: completion) }
            
            if let data = data {
                do {
                    
                    var repositories = [Repository]()
                    
                    if let json = try NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions()) as? [[String : AnyObject]] {
                        for repositoryJSON in json {
                            if let repository = Repository(json: repositoryJSON) {
                                repositories.append(repository)
                            }
                        }
                        
                        self.returnOnMain(repositories, completion: completion)
                    }
                }
                
                catch {
                    self.returnOnMain(nil, completion: completion)
                }
            }
            
        }.resume()
    }
    
    func GETUser(completion: (user: User?) -> ())
    {
        self.template.path = "/user"
        self.session.dataTaskWithURL(self.template.URL!) { (data, response, error) in
            
            if let error = error {
                print(error)
            }
            
            if let data = data {
                do {
                    
                    if let json = try NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions()) as? [String : AnyObject] {
                        
                        // Create the user...
                        
                        let user = User(json: json)
                        
                        NSOperationQueue.mainQueue().addOperationWithBlock({
                            completion(user: user)
                        })
                    }
                }
                
                catch {
                    print(error)
                }
            }
            
        }.resume()
    }
    
    func POSTRepository(name: String, completion:(success: Bool) -> ())
    {
        self.template.path = "/user/repos"
        
        let request = NSMutableURLRequest(URL: self.template.URL!)
        request.HTTPMethod = "POST"
        request.HTTPBody = try? NSJSONSerialization.dataWithJSONObject(["name" : name], options: .PrettyPrinted)
        
        self.session.dataTaskWithRequest(request) { (data, response, error) in
            if let response = response as? NSHTTPURLResponse {
                switch response.statusCode {
                case 200...299:
                    NSOperationQueue.mainQueue().addOperationWithBlock({ 
                        completion(success: true)
                    })
                    
                default:
                    NSOperationQueue.mainQueue().addOperationWithBlock({ 
                        completion(success: false)
                    })
                }
            }
            
        }.resume()
        
    }
    
    private func returnOnMain(repositories: [Repository]?, completion: (repositories: [Repository]?) -> ()) {
        NSOperationQueue.mainQueue().addOperationWithBlock({
            completion(repositories: repositories)
        })
    }
}