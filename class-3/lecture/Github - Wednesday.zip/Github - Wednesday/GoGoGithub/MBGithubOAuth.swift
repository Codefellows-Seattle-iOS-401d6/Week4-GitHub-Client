//
//  MBGithubOAuth.swift
//  MBGithubOAuth
//
//  Created by Michael Babiy on 10/20/15.
//  Copyright © 2015 Michael Babiy. All rights reserved.
//

import UIKit

let kAccessTokenKey = "kAccessTokenKey"
let kOAuthBaseURLString = "https://github.com/login/oauth/"
let kAccessTokenRegexPattern = "access_token=([^&]+)"

typealias MBGithubOAuthCompletion = (success: Bool) -> ()

enum MBGithubOAuthError: ErrorType
{
    case MissingAccessToken(String)
    case ExtractingTokenFromString(String)
    case ExtractingTermporaryCode(String)
    case ResponseFromGithub(String)
}

enum SaveOptions: Int
{
    case UserDefaults
    case Keychain
}

class MBGithubOAuth
{
    /*
        Setup your Github client id and your client secret first.
    */
    
    var githubClientId = "01c23e0a252086c9edd7"
    var githubClientSecret = "2f305de1650d4959da1301047b8264e3fb3eaa7c"
    
    static let shared = MBGithubOAuth()

    func oauthRequestWith(scope: String)
    {
        guard let requestURL = NSURL(string: "\(kOAuthBaseURLString)authorize?client_id=\(self.githubClientId)&scope=\(scope)") else {
            fatalError("Error constructing initial URL string.")
        }
        
        UIApplication.sharedApplication().openURL(requestURL)
    }
    
    func tokenRequestWithCallback(url: NSURL, options: SaveOptions, completion: MBGithubOAuthCompletion)
    {
        func completeOnMain(success: Bool, _ completion: (Bool) -> ()) {
            NSOperationQueue.mainQueue().addOperationWithBlock({ completion(success) })
        }
        
        do {
            let temporaryCode = try self.temporaryCodeFromCallback(url)
            let requestString = "\(kOAuthBaseURLString)access_token?client_id=\(self.githubClientId)&client_secret=\(self.githubClientSecret)&code=\(temporaryCode)"
            
            if let requestURL = NSURL(string: requestString) {
                
                let sessionConfiguration = NSURLSessionConfiguration.defaultSessionConfiguration()
                let session = NSURLSession(configuration: sessionConfiguration)
                session.dataTaskWithURL(requestURL, completionHandler: { (data, response, error) -> Void in
                    
                    if let _ = error {
                        completeOnMain(false, completion); return
                    }
                    
                    if let data = data {
                        if let tokenString = self.stringWith(data) {
                            
                            do {
                                let token = try self.accessTokenFromString(tokenString)!
                                
                                switch options {
                                    case .UserDefaults: completeOnMain(self.saveAccessTokenToUserDefaults(token), completion)
                                    case .Keychain: completeOnMain(self.saveTokenToKeychain(token), completion)
                                }
                                
                            } catch _ {
                                completeOnMain(false, completion)
                            }
                        
                        }
                    }
                }).resume()
            }
            
        }
        
        catch {
            completeOnMain(false, completion)
        }
    }
    
    func accessToken() throws -> String?
    {
        var query = keychainQuery(kAccessTokenKey)
        
        query[(kSecReturnData as String)] = kCFBooleanTrue
        query[(kSecMatchLimit as String)] = kSecMatchLimitOne
        
        var dataRef: AnyObject?
        
        if SecItemCopyMatching(query, &dataRef) == errSecSuccess {
            if let data = dataRef as? NSData {
                if let token = NSKeyedUnarchiver.unarchiveObjectWithData(data) as? String {
                    return token
                }
            }
        }
        
        else {
            guard let token = NSUserDefaults.standardUserDefaults().stringForKey(kAccessTokenKey) else {
                throw MBGithubOAuthError.MissingAccessToken("You don't have access token saved.")
            }
            
            return token

        }
        
        return nil
    }
    
    // MARK: Helper Functions
    
    private func temporaryCodeFromCallback(url: NSURL) throws -> String
    {
        guard let temporaryCode = url.absoluteString.componentsSeparatedByString("=").last else {
            throw MBGithubOAuthError.ExtractingTermporaryCode("Error ExtractingTermporaryCode. See: temporaryCodeFromCallback:")
        }
        
        return temporaryCode
    }
    
    private func accessTokenFromString(string: String) throws -> String?
    {
        do {
            let regex = try NSRegularExpression(pattern: kAccessTokenRegexPattern, options: NSRegularExpressionOptions.CaseInsensitive)
            let matches = regex.matchesInString(string, options: NSMatchingOptions.Anchored, range: NSMakeRange(0, string.characters.count))
            if matches.count > 0 {
                for (_, value) in matches.enumerate() {
                    let matchRange = value.rangeAtIndex(1)
                    return (string as NSString).substringWithRange(matchRange)
                }
            }
        }
        
        catch {
            throw MBGithubOAuthError.ExtractingTokenFromString("Could not extract token from string.")
        }
        
        return nil
    }
    
    private func stringWith(data: NSData) -> String?
    {
        let byteBuffer: UnsafeBufferPointer<UInt8> = UnsafeBufferPointer<UInt8>(start: UnsafeMutablePointer<UInt8>(data.bytes), count: data.length)
        return String(bytes: byteBuffer, encoding: NSASCIIStringEncoding)
    }
    
    // MARK: UserDefaults
    
    private func saveAccessTokenToUserDefaults(accessToken: String) -> Bool
    {
        NSUserDefaults.standardUserDefaults().setObject(accessToken, forKey: kAccessTokenKey)
        return NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    // MARK: Keychain
    
    private func keychainQuery(query: String) -> [String : AnyObject]
    {
        return [
            (kSecClass as String) : kSecClassGenericPassword, // Type
            (kSecAttrService as String) : query, // Typically the name of the app / service - GoGoGithub
            (kSecAttrAccount as String) : query, // Typically username - kAccessToken (bad name)
            (kSecAttrAccessible as String) : kSecAttrAccessibleAfterFirstUnlock, // Available after restart's first unlock
        ]
    }
    
    func saveTokenToKeychain(token: String) -> Bool
    {
        var query = keychainQuery(kAccessTokenKey)
        query[(kSecValueData as String)] = NSKeyedArchiver.archivedDataWithRootObject(token)
        SecItemDelete(query)
        return SecItemAdd(query, nil) == errSecSuccess
    }
}